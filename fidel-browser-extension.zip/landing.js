"use strict";
(() => {
  // src/engine/mapping.ts
  var FIDEL_FAMILIES = {
    // h (ሀ)
    h: { e: "\u1200", u: "\u1201", i: "\u1202", a: "\u1203", ee: "\u1204", "": "\u1205", o: "\u1206", wa: "\u128B" },
    // l (ለ)
    l: { e: "\u1208", u: "\u1209", i: "\u120A", a: "\u120B", ee: "\u120C", "": "\u120D", o: "\u120E", wa: "\u120F" },
    // H / hh (ሐ)
    H: { e: "\u1210", u: "\u1211", i: "\u1212", a: "\u1213", ee: "\u1214", "": "\u1215", o: "\u1216", wa: "\u1217" },
    hh: { e: "\u1210", u: "\u1211", i: "\u1212", a: "\u1213", ee: "\u1214", "": "\u1215", o: "\u1216", wa: "\u1217" },
    // m (መ)
    m: { e: "\u1218", u: "\u1219", i: "\u121A", a: "\u121B", ee: "\u121C", "": "\u121D", o: "\u121E", wa: "\u121F" },
    // ss / S / s' (ሠ)
    ss: { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    S: { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    "s'": { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    // r (ረ)
    r: { e: "\u1228", u: "\u1229", i: "\u122A", a: "\u122B", ee: "\u122C", "": "\u122D", o: "\u122E", wa: "\u122F" },
    // s (ሰ)
    s: { e: "\u1230", u: "\u1231", i: "\u1232", a: "\u1233", ee: "\u1234", "": "\u1235", o: "\u1236", wa: "\u1237" },
    // sh (ሸ)
    sh: { e: "\u1238", u: "\u1239", i: "\u123A", a: "\u123B", ee: "\u123C", "": "\u123D", o: "\u123E", wa: "\u123F" },
    // q / k' / K / Q (ቀ)
    q: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    "k'": { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    K: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    Q: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    // b (በ)
    b: { e: "\u1260", u: "\u1261", i: "\u1262", a: "\u1263", ee: "\u1264", "": "\u1265", o: "\u1266", wa: "\u1267" },
    // v / V / B / b' (ቨ)
    v: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    V: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    B: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    "b'": { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    // t (ተ)
    t: { e: "\u1270", u: "\u1271", i: "\u1272", a: "\u1273", ee: "\u1274", "": "\u1275", o: "\u1276", wa: "\u1277" },
    // ch / c (ቸ)
    ch: { e: "\u1278", u: "\u1279", i: "\u127A", a: "\u127B", ee: "\u127C", "": "\u127D", o: "\u127E", wa: "\u127F" },
    c: { e: "\u1278", u: "\u1279", i: "\u127A", a: "\u127B", ee: "\u127C", "": "\u127D", o: "\u127E", wa: "\u127F" },
    // h' / xh / hx (ኀ)
    "h'": { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    xh: { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    hx: { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    // n (ነ)
    n: { e: "\u1290", u: "\u1291", i: "\u1292", a: "\u1293", ee: "\u1294", "": "\u1295", o: "\u1296", wa: "\u1297" },
    // ny / GN / N / n' (ኘ)
    ny: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    GN: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    N: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    "n'": { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    // ' / ea (አ - Alef consonant family)
    "'": { e: "\u12A0", u: "\u12A1", i: "\u12A2", a: "\u12A3", ee: "\u12A4", "": "\u12A5", o: "\u12A6", wa: "\u12A7" },
    ea: { e: "\u12A0", u: "\u12A1", i: "\u12A2", a: "\u12A3", ee: "\u12A4", "": "\u12A0", o: "\u12A6", wa: "\u12A7" },
    // k (ከ)
    k: { e: "\u12A8", u: "\u12A9", i: "\u12AA", a: "\u12AB", ee: "\u12AC", "": "\u12AD", o: "\u12AE", wa: "\u12B3" },
    // kh / x / X (ኸ)
    kh: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    x: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    X: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    // w (ወ)
    w: { e: "\u12C8", u: "\u12C9", i: "\u12CA", a: "\u12CB", ee: "\u12CC", "": "\u12CD", o: "\u12CE" },
    // ah / A / a' (ዐ)
    ah: { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    A: { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    "a'": { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    // z (ዘ)
    z: { e: "\u12D8", u: "\u12D9", i: "\u12DA", a: "\u12DB", ee: "\u12DC", "": "\u12DD", o: "\u12DE", wa: "\u12DF" },
    // zh / Z / z' (ዠ)
    zh: { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    Z: { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    "z'": { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    // y (የ)
    y: { e: "\u12E8", u: "\u12E9", i: "\u12ED", a: "\u12EB", ee: "\u12EC", "": "\u12ED", o: "\u12EE" },
    // d (ደ)
    d: { e: "\u12F0", u: "\u12F1", i: "\u12F2", a: "\u12F3", ee: "\u12F4", "": "\u12F5", o: "\u12F6", wa: "\u12F7" },
    // j (ጀ)
    j: { e: "\u1300", u: "\u1301", i: "\u1302", a: "\u1303", ee: "\u1304", "": "\u1305", o: "\u1306", wa: "\u1307" },
    // g (ገ)
    g: { e: "\u1308", u: "\u1309", i: "\u130A", a: "\u130B", ee: "\u130C", "": "\u130D", o: "\u130E", wa: "\u1313" },
    // t' / T (ጠ)
    "t'": { e: "\u1320", u: "\u1321", i: "\u1322", a: "\u1323", ee: "\u1324", "": "\u1325", o: "\u1326", wa: "\u1327" },
    T: { e: "\u1320", u: "\u1321", i: "\u1322", a: "\u1323", ee: "\u1324", "": "\u1325", o: "\u1326", wa: "\u1327" },
    // c' / CH / C (ጨ)
    "c'": { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    CH: { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    C: { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    // p' / P (ጰ)
    "p'": { e: "\u1330", u: "\u1331", i: "\u1332", a: "\u1333", ee: "\u1334", "": "\u1335", o: "\u1336", wa: "\u1337" },
    P: { e: "\u1330", u: "\u1331", i: "\u1332", a: "\u1333", ee: "\u1334", "": "\u1335", o: "\u1336", wa: "\u1337" },
    // ts / tz / Tz / S' / Ts / ts' (ጸ / ፀ)
    ts: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    Ts: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    Tz: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    "S'": { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    tz: { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    TZ: { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    "ts'": { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    // f (ፈ)
    f: { e: "\u1348", u: "\u1349", i: "\u134A", a: "\u134B", ee: "\u134C", "": "\u134D", o: "\u134E", wa: "\u134F" },
    // p (ፐ)
    p: { e: "\u1350", u: "\u1351", i: "\u1352", a: "\u1353", ee: "\u1354", "": "\u1355", o: "\u1356", wa: "\u1357" }
  };
  var PUNCTUATION_MAP = {
    // 1. Distinct 1-to-1 Keyboard Triggers
    ".": "\u1362",
    // Ethiopic Full Stop / Arat Neteb (አራት ነጥብ)
    ",": "\u1363",
    // Ethiopic Comma / Netela Serez (ነጠላ ሰረዝ)
    ";": "\u1364",
    // Ethiopic Semicolon / Derb Serez (ድርብ ሰረዝ)
    ":": "\u1361",
    // Ethiopic Wordspace / Hulat Neteb (ሁለት ነጥብ)
    "?": "\u1367",
    // Ethiopic Question Mark / Yimer (ይመር)
    "|": "\u1365",
    // Ethiopic Colon / Sost Neteb (ሦስት ነጥብ / አንቀጽ)
    ">": "\u1366",
    // Ethiopic Preface Colon / Meqereya (መቅረዝ)
    "@": "\u1360",
    // Ethiopic Section Mark / Ayne T'ila (ዓይነ ጥላ)
    "#": "\u1368",
    // Ethiopic Paragraph Separator / Yieti (ይእቲ)
    "~": "\u135F",
    // Ethiopic Combining Gemination Mark / T'ebiq (ጥብቅ)
    // 2. Multi-character & Shorthand Aliases
    "::": "\u1362",
    // Arat Neteb alias
    "..": "\u1362",
    // Arat Neteb alias
    ",,": "\u1364",
    // Derb Serez alias
    ":-": "\u1365",
    // Sost Neteb alias
    ":-:": "\u1366",
    // Meqereya alias
    ":::": "\u1366",
    // Meqereya alias
    "*": "\u1360",
    // Ayne T'ila alias
    "@@": "\u1360",
    // Ayne T'ila alias
    "**": "\u1368",
    // Yieti alias
    "***": "\u1368",
    // Yieti alias
    "##": "\u1368",
    // Yieti alias
    "_": "\u135F"
    // Gemination Mark alias
  };
  var COMMON_WORD_MAP = {
    // Common greetings & expressions
    selam: "\u1230\u120B\u121D",
    endemin: "\u12A5\u1295\u12F0\u121D\u1295",
    tena: "\u1324\u1293",
    tenayistillign: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    tenayistilign: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    tenayistilln: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    ameseginalehu: "\u12A0\u1218\u1230\u130D\u1293\u1208\u1201",
    amesegenalehu: "\u12A0\u1218\u1230\u130D\u1293\u1208\u1201",
    dehna: "\u12F0\u1205\u1293",
    ishii: "\u12A5\u123A",
    ishi: "\u12A5\u123A",
    awo: "\u12A0\u12CE",
    yellem: "\u12E8\u1208\u121D",
    yelem: "\u12E8\u1208\u121D",
    // Family & Relationships
    enat: "\u12A5\u1293\u1275",
    abat: "\u12A0\u1263\u1275",
    wendim: "\u12C8\u1295\u12F5\u121D",
    ihit: "\u12A5\u1205\u1275",
    lij: "\u120D\u1305",
    lijoch: "\u120D\u1306\u127D",
    wodaj: "\u12C8\u12F3\u1305",
    gwad: "\u1313\u12F5",
    // Places & Country
    ethiopia: "\u12A2\u1275\u12EE\u1335\u12EB",
    ityopya: "\u12A2\u1275\u12EE\u1335\u12EB",
    "ityop'ya": "\u12A2\u1275\u12EE\u1335\u12EB",
    ethiopian: "\u12A2\u1275\u12EE\u1335\u12EB\u12CA",
    amharic: "\u12A0\u121B\u122D\u129B",
    amaric: "\u12A0\u121B\u122D\u129B",
    amharik: "\u12A0\u121B\u122D\u129B",
    fidel: "\u134A\u12F0\u120D",
    addis: "\u12A0\u12F2\u1235",
    adis: "\u12A0\u12F2\u1235",
    ababa: "\u12A0\u1260\u1263",
    abeba: "\u12A0\u1260\u1263",
    addisababa: "\u12A0\u12F2\u1235 \u12A0\u1260\u1263",
    addisabeba: "\u12A0\u12F2\u1235 \u12A0\u1260\u1263",
    amhara: "\u12A0\u121B\u122B",
    oromia: "\u12A6\u122E\u121A\u12EB",
    tigray: "\u1275\u130D\u122B\u12ED",
    habesha: "\u1200\u1260\u123B",
    // Religious & Cultural Names / Terms
    egziabher: "\u12A5\u130D\u12DA\u12A0\u1265\u1214\u122D",
    igziabher: "\u12A5\u130D\u12DA\u12A0\u1265\u1214\u122D",
    mariam: "\u121B\u122A\u12EB\u121D",
    maryam: "\u121B\u122A\u12EB\u121D",
    mikael: "\u121A\u12AB\u12A4\u120D",
    michael: "\u121A\u12AB\u12A4\u120D",
    gebriel: "\u1308\u1265\u122D\u12A4\u120D",
    gabriel: "\u1308\u1265\u122D\u12A4\u120D",
    kidus: "\u1245\u12F1\u1235",
    "k'idus": "\u1245\u12F1\u1235",
    qidus: "\u1245\u12F1\u1235",
    qdus: "\u1245\u12F1\u1235",
    yared: "\u12EB\u122C\u12F5",
    yareed: "\u12EB\u122C\u12F5",
    // Common Amharic Personal Names
    abebe: "\u12A0\u1260\u1260",
    bet: "\u1264\u1275",
    beet: "\u1264\u1275",
    yihun: "\u12ED\u1201\u1295",
    haile: "\u1283\u12ED\u1208",
    hayle: "\u1283\u12ED\u1208",
    hailemichael: "\u1283\u12ED\u1208\u121A\u12AB\u12A4\u120D",
    haylemikael: "\u1283\u12ED\u1208\u121A\u12AB\u12A4\u120D",
    haileselassie: "\u1283\u12ED\u1208\u1225\u120B\u1234",
    hayleselassie: "\u1283\u12ED\u1208\u1225\u120B\u1234",
    shekuri: "\u1238\u12A9\u122A",
    dawit: "\u12F3\u12CA\u1275",
    dawiit: "\u12F3\u12CA\u1275",
    solomon: "\u1230\u1208\u121E\u1295",
    yohannes: "\u12EE\u1210\u1295\u1235",
    tesfaye: "\u1270\u1235\u134B\u12EC",
    worku: "\u12C8\u122D\u1241",
    berhanu: "\u1265\u122D\u1203\u1291",
    girma: "\u130D\u122D\u121B",
    getachew: "\u130C\u1273\u1278\u12CD",
    tadesse: "\u1273\u12F0\u1230",
    tadese: "\u1273\u12F0\u1230",
    kebede: "\u12A8\u1260\u12F0",
    bekele: "\u1260\u1240\u1208",
    mulugeta: "\u1219\u1209\u130C\u1273",
    mulu: "\u1219\u1209",
    almaz: "\u12A0\u120D\u121B\u12DD",
    aster: "\u12A0\u1235\u1274\u122D",
    genet: "\u1308\u1290\u1275",
    tigist: "\u1275\u12D5\u130D\u1225\u1275",
    meseret: "\u1218\u1220\u1228\u1275",
    helen: "\u1214\u1208\u1295",
    amanuel: "\u12A0\u121B\u1291\u12A4\u120D",
    kifle: "\u12AD\u134D\u120C",
    // Titles & Common Nouns
    ato: "\u12A0\u1276",
    woizero: "\u12C8\u12ED\u12D8\u122E",
    weyzerit: "\u12C8\u12ED\u12D8\u122A\u1275",
    timhirt: "\u1275\u121D\u1205\u122D\u1275",
    timhirtbet: "\u1275\u121D\u1205\u122D\u1275 \u1264\u1275",
    sira: "\u1225\u122B",
    wuha: "\u12CD\u1203",
    wuhah: "\u12CD\u1203",
    beso: "\u1260\u1236",
    bela: "\u1260\u120B",
    mewad: "\u1218\u12CB\u12F5"
  };
  function buildFlatMapping() {
    const map = {};
    const H_FAMILY_PREFIXES = /* @__PURE__ */ new Set([
      "h",
      "H",
      "hh",
      "h'",
      "xh",
      "hx",
      "ah",
      "A",
      "a'"
    ]);
    const STANDALONE_VOWEL_PREFIXES = /* @__PURE__ */ new Set(["a", "e", "E", "i", "u", "o"]);
    for (const [prefix, family] of Object.entries(FIDEL_FAMILIES)) {
      if (STANDALONE_VOWEL_PREFIXES.has(prefix)) continue;
      map[prefix] = family[""];
      if (H_FAMILY_PREFIXES.has(prefix)) {
        map[prefix + "a"] = family.e;
        map[prefix + "aa"] = family.a;
        map[prefix + "e"] = family.ee;
        map[prefix + "ee"] = family.ee;
        map[prefix + "ie"] = family.ee;
      } else {
        map[prefix + "e"] = family.e;
        map[prefix + "a"] = family.a;
        map[prefix + "ee"] = family.ee;
        map[prefix + "ie"] = family.ee;
      }
      map[prefix + "u"] = family.u;
      map[prefix + "i"] = family.i;
      map[prefix + "o"] = family.o;
      if (family.wa) {
        map[prefix + "w"] = family.wa;
        map[prefix + "wa"] = family.wa;
        map[prefix + "oa"] = family.wa;
      }
    }
    for (const [prefix, family] of Object.entries(FIDEL_FAMILIES)) {
      if (STANDALONE_VOWEL_PREFIXES.has(prefix)) continue;
      const titlePrefix = prefix.length > 0 ? prefix[0].toUpperCase() + prefix.slice(1).toLowerCase() : prefix;
      const upperPrefix = prefix.toUpperCase();
      const variants = [titlePrefix, upperPrefix];
      const isHFamily = H_FAMILY_PREFIXES.has(prefix);
      const aTarget = isHFamily ? family.e : family.a;
      const eTarget = isHFamily ? family.ee : family.e;
      const suffixEntries = [
        ["", family[""]],
        ["e", eTarget],
        ["a", aTarget],
        ["u", family.u],
        ["i", family.i],
        ...isHFamily ? [["aa", family.a]] : [],
        ["ee", family.ee],
        ["ie", family.ee],
        ["o", family.o],
        ["w", family.wa],
        ["wa", family.wa],
        ["oa", family.wa]
      ];
      for (const vPrefix of variants) {
        for (const [suf, target] of suffixEntries) {
          if (!target) continue;
          const key = vPrefix + suf;
          if (map[key] === void 0) {
            map[key] = target;
          }
        }
      }
    }
    const standaloneVowels = [
      // 6th order standalone (እ)
      ["e", "\u12A5"],
      ["E", "\u12A5"],
      // 5th order standalone (ኤ)
      ["ee", "\u12A4"],
      ["EE", "\u12A4"],
      ["Ee", "\u12A4"],
      ["eE", "\u12A4"],
      ["ie", "\u12A4"],
      ["IE", "\u12A4"],
      ["Ie", "\u12A4"],
      // 1st order standalone (አ)
      ["a", "\u12A0"],
      ["ea", "\u12A0"],
      // 4th order standalone (ኣ)
      ["aa", "\u12A3"],
      ["AA", "\u12A3"],
      // 2nd order standalone (ኡ)
      ["u", "\u12A1"],
      ["uu", "\u12A1"],
      ["U", "\u12A1"],
      ["UU", "\u12A1"],
      // 3rd order standalone (ኢ)
      ["i", "\u12A2"],
      ["ii", "\u12A2"],
      ["I", "\u12A2"],
      ["II", "\u12A2"],
      // 7th order standalone (ኦ)
      ["o", "\u12A6"],
      ["oo", "\u12A6"],
      ["O", "\u12A6"],
      ["OO", "\u12A6"]
    ];
    for (const [vKey, vVal] of standaloneVowels) {
      map[vKey] = vVal;
    }
    for (const [word, ethiopic] of Object.entries(COMMON_WORD_MAP)) {
      map[word] = ethiopic;
      map[word.toLowerCase()] = ethiopic;
      map[word.toUpperCase()] = ethiopic;
      if (word.length > 0) {
        map[word[0].toUpperCase() + word.slice(1).toLowerCase()] = ethiopic;
      }
    }
    return map;
  }

  // src/engine/trie.ts
  var TrieNode = class {
    children = /* @__PURE__ */ new Map();
    ethiopic;
    isEnd = false;
    output = null;
  };
  var sharedRoot = null;
  var FidelTrie = class {
    root;
    constructor() {
      if (!sharedRoot) {
        sharedRoot = new TrieNode();
        this.root = sharedRoot;
        this.init();
      } else {
        this.root = sharedRoot;
      }
    }
    static resetSharedRoot() {
      sharedRoot = null;
    }
    init() {
      const flatMap = buildFlatMapping();
      for (const [latin, ethiopic] of Object.entries(flatMap)) {
        this.insert(latin, ethiopic);
      }
    }
    insert(latin, ethiopic) {
      let targetOutput = ethiopic;
      let sequence = latin;
      if (typeof latin === "object" && latin.input) {
        sequence = latin.input;
        targetOutput = latin.output;
      }
      let current = this.root;
      for (let i = 0; i < sequence.length; i++) {
        const char = sequence[i];
        if (!current.children.has(char)) {
          current.children.set(char, new TrieNode());
        }
        current = current.children.get(char);
      }
      current.ethiopic = targetOutput;
      current.output = targetOutput || null;
      current.isEnd = true;
    }
    search(latin) {
      if (!latin) {
        return { type: "none" };
      }
      let current = this.root;
      for (let i = 0; i < latin.length; i++) {
        const char = latin[i];
        if (!current.children.has(char)) {
          return { type: "none" };
        }
        current = current.children.get(char);
      }
      if (current.isEnd && current.ethiopic) {
        const canContinue = current.children.size > 0;
        return {
          type: "exact",
          output: current.ethiopic,
          matchedLength: latin.length,
          canContinue
        };
      }
      if (current.children.size > 0) {
        return { type: "prefix" };
      }
      return { type: "none" };
    }
    findLongestMatch(latin) {
      let current = this.root;
      let lastMatch = null;
      for (let i = 0; i < latin.length; i++) {
        const char = latin[i];
        if (!current.children.has(char)) {
          break;
        }
        current = current.children.get(char);
        if (current.isEnd && current.output) {
          lastMatch = {
            output: current.output,
            matchedLength: i + 1
          };
        }
      }
      return lastMatch;
    }
    match(input, offset = 0) {
      const remaining = input.slice(offset);
      const result = this.findLongestMatch(remaining);
      if (!result) return null;
      return {
        output: result.output,
        consumed: result.matchedLength,
        terminal: false
      };
    }
  };

  // src/engine/numbers.ts
  var ETHIOPIC_DIGITS = {
    "1": "\u1369",
    "2": "\u136A",
    "3": "\u136B",
    "4": "\u136C",
    "5": "\u136D",
    "6": "\u136E",
    "7": "\u136F",
    "8": "\u1370",
    "9": "\u1371"
  };
  var ETHIOPIC_TENS = {
    "10": "\u1372",
    "20": "\u1373",
    "30": "\u1374",
    "40": "\u1375",
    "50": "\u1376",
    "60": "\u1377",
    "70": "\u1378",
    "80": "\u1379",
    "90": "\u137A"
  };
  var HUNDRED = "\u137B";
  var TEN_THOUSAND = "\u137C";
  function convertNumberToEthiopic(numStr) {
    const sanitized = numStr.replace(/^0+/, "");
    if (!sanitized) {
      return numStr === "0" ? "0" : numStr;
    }
    const num = parseInt(sanitized, 10);
    if (isNaN(num) || num <= 0) {
      return numStr;
    }
    if (num < 10) {
      return ETHIOPIC_DIGITS[sanitized] || numStr;
    }
    if (num < 100) {
      const tens = Math.floor(num / 10) * 10;
      const ones = num % 10;
      let res2 = "";
      if (tens > 0 && ETHIOPIC_TENS[tens.toString()]) {
        res2 += ETHIOPIC_TENS[tens.toString()];
      }
      if (ones > 0 && ETHIOPIC_DIGITS[ones.toString()]) {
        res2 += ETHIOPIC_DIGITS[ones.toString()];
      }
      return res2;
    }
    if (num < 1e4) {
      const hundreds = Math.floor(num / 100);
      const remainder2 = num % 100;
      let res2 = "";
      if (hundreds > 0) {
        const hundredPrefix = convertNumberToEthiopic(hundreds.toString());
        if (hundredPrefix === "\u1369") {
          res2 += HUNDRED;
        } else {
          res2 += hundredPrefix + HUNDRED;
        }
      }
      if (remainder2 > 0) {
        res2 += convertNumberToEthiopic(remainder2.toString());
      }
      return res2;
    }
    const myriads = Math.floor(num / 1e4);
    const remainder = num % 1e4;
    let res = "";
    if (myriads > 0) {
      const myriadPrefix = convertNumberToEthiopic(myriads.toString());
      if (myriadPrefix === "\u1369") {
        res += TEN_THOUSAND;
      } else {
        res += myriadPrefix + TEN_THOUSAND;
      }
    }
    if (remainder > 0) {
      res += convertNumberToEthiopic(remainder.toString());
    }
    return res;
  }
  function convertNumbersInText(text, enabled) {
    if (!enabled) {
      return text;
    }
    return text.replace(/\b\d+\b/g, (match) => {
      return convertNumberToEthiopic(match);
    });
  }

  // src/engine/dictionary.ts
  var PersonalDictionary = class {
    entries = /* @__PURE__ */ new Map();
    constructor(initialEntries) {
      if (initialEntries) {
        this.setEntries(initialEntries);
      }
    }
    addEntry(latin, ethiopic) {
      if (!latin || !ethiopic) {
        return;
      }
      const key = latin.trim().toLowerCase();
      this.entries.set(key, ethiopic.trim());
    }
    removeEntry(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.delete(key);
    }
    get(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.get(key) ?? null;
    }
    has(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.has(key);
    }
    setEntries(records) {
      this.entries.clear();
      for (const [key, val] of Object.entries(records)) {
        if (key && val) {
          this.entries.set(key.trim().toLowerCase(), val.trim());
        }
      }
    }
    getEntries() {
      const result = {};
      for (const [key, val] of this.entries.entries()) {
        result[key] = val;
      }
      return result;
    }
    clear() {
      this.entries.clear();
    }
  };

  // src/engine/corrector.ts
  var SmartCorrector = class {
    /**
     * Generates candidate normalized phonetic spellings for non-standard inputs.
     * e.g., "selamm" -> "selam", "yihunn" -> "yihun", "beett" -> "bet", "amhariph" -> "amharif"
     */
    normalizeInput(input) {
      if (!input || input.length < 3) {
        return [input];
      }
      const candidates = [input];
      const collapsedTrailing = input.replace(/(.)\1+$/, "$1");
      if (collapsedTrailing !== input) {
        candidates.push(collapsedTrailing);
      }
      const collapsedAll = input.replace(/(.)\1+/g, "$1");
      if (collapsedAll !== input && !candidates.includes(collapsedAll)) {
        candidates.push(collapsedAll);
      }
      if (input.includes("ph")) {
        const phSubbed = input.replace(/ph/g, "f");
        if (!candidates.includes(phSubbed)) {
          candidates.push(phSubbed);
        }
      }
      if (input.includes("ck")) {
        const ckSubbed = input.replace(/ck/g, "k");
        if (!candidates.includes(ckSubbed)) {
          candidates.push(ckSubbed);
        }
      }
      return candidates;
    }
    /**
     * Attempts to correct a non-standard input word using candidate normalizations
     * and a provided lookup function.
     */
    correctWord(input, lookupFn) {
      const candidates = this.normalizeInput(input);
      for (const cand of candidates) {
        const match = lookupFn(cand);
        if (match) {
          return match;
        }
      }
      return null;
    }
  };

  // src/engine/transliterator.ts
  var DEFAULT_OPTIONS = {
    caseSensitive: true,
    convertPunctuation: false,
    convertNumbers: false,
    dictionary: {},
    smartCorrection: false,
    suggestions: false,
    language: "amharic"
  };
  var Transliterator = class _Transliterator {
    trie = new FidelTrie();
    options;
    dictionary;
    corrector = new SmartCorrector();
    constructor(options = {}) {
      this.options = {
        ...DEFAULT_OPTIONS,
        ...options
      };
      this.dictionary = new PersonalDictionary(this.options.dictionary);
    }
    transliterate(input) {
      if (!input) {
        return "";
      }
      const dictMatch = this.dictionary.get(input);
      if (dictMatch) {
        return dictMatch;
      }
      if (this.options.convertNumbers) {
        input = convertNumbersInText(input, true);
      }
      const commonWord = this.lookupCommonWord(input);
      if (commonWord) {
        return commonWord;
      }
      if (this.options.smartCorrection && input.length > 2) {
        const candidates = this.corrector.normalizeInput(input);
        for (const cand of candidates) {
          if (cand !== input) {
            const dictCand = this.dictionary.get(cand);
            if (dictCand) return dictCand;
            const commonCand = this.lookupCommonWord(cand);
            if (commonCand) return commonCand;
          }
        }
      }
      const output = this.matchTrie(input);
      if (this.options.smartCorrection && input.length > 2 && /[a-zA-Z]/.test(output)) {
        const candidates = this.corrector.normalizeInput(input);
        for (const cand of candidates) {
          if (cand !== input) {
            const candResult = this.matchTrie(cand);
            if (candResult && candResult !== cand && !/[a-zA-Z]/.test(candResult)) {
              if (/[a-zA-Z]/.test(output) || output !== candResult) {
                return candResult;
              }
            }
          }
        }
      }
      return output;
    }
    transliterateWord(input) {
      return this.transliterate(input);
    }
    // FIXED: No more infinite recursion!
    transliterateText(text, options) {
      if (options) {
        const opts = { ...this.options, ...options };
        const instance = new _Transliterator(opts);
        const parts2 = text.split(/(\s+)/);
        const result2 = parts2.map((part) => {
          if (part.trim().length === 0) {
            return part;
          }
          return instance.transliterate(part);
        }).join("");
        return result2;
      }
      const parts = text.split(/(\s+)/);
      const result = parts.map((part) => {
        if (part.trim().length === 0) {
          return part;
        }
        return this.transliterate(part);
      }).join("");
      return result;
    }
    matchAt(input, offset) {
      const source = this.options.caseSensitive ? input : input.toLowerCase();
      return this.findMatch(source, offset);
    }
    matchTrie(input) {
      const source = this.options.caseSensitive ? input : input.toLowerCase();
      let output = "";
      let offset = 0;
      while (offset < source.length) {
        if (this.options.convertPunctuation) {
          if (offset + 3 <= source.length) {
            const tripleChar = source.slice(offset, offset + 3);
            if (PUNCTUATION_MAP[tripleChar]) {
              output += PUNCTUATION_MAP[tripleChar];
              offset += 3;
              continue;
            }
          }
          if (offset + 2 <= source.length) {
            const doubleChar = source.slice(offset, offset + 2);
            if (PUNCTUATION_MAP[doubleChar]) {
              output += PUNCTUATION_MAP[doubleChar];
              offset += 2;
              continue;
            }
          }
        }
        const match = this.findMatch(source, offset);
        if (match) {
          output += match.output;
          offset += match.consumed;
          continue;
        }
        const character = input[offset];
        if (this.options.convertPunctuation && PUNCTUATION_MAP[character]) {
          output += PUNCTUATION_MAP[character];
        } else {
          output += character;
        }
        offset += 1;
      }
      return output;
    }
    findMatch(source, offset) {
      return this.trie.match(source, offset);
    }
    lookupCommonWord(input) {
      return COMMON_WORD_MAP[input] ?? COMMON_WORD_MAP[input.toLowerCase()] ?? null;
    }
  };

  // src/engine/composition.ts
  var CompositionEngine = class {
    transliterator;
    trie;
    defaultSyllableMerging;
    boundaryChar;
    mergeChar;
    maxKeyLength;
    lockedOutput = "";
    lockedRaw = "";
    pendingFragment = "";
    forceNextMerge = false;
    previousRendered = "";
    ambiguousSpans = [];
    constructor(options = {}) {
      this.transliterator = new Transliterator(options);
      this.trie = new FidelTrie();
      this.defaultSyllableMerging = options.defaultSyllableMerging ?? "merge";
      this.boundaryChar = options.compositionBoundaryChar ?? "-";
      this.mergeChar = options.compositionMergeChar ?? "+";
      this.maxKeyLength = 8;
    }
    getState() {
      const rendered = this.renderBuffer();
      return {
        buffer: this.lockedRaw + this.pendingFragment,
        rendered,
        committed: false,
        replaceLength: this.previousRendered.length,
        raw: this.lockedRaw + this.pendingFragment,
        output: rendered,
        lockedOutput: this.lockedOutput,
        pendingFragment: this.pendingFragment,
        ambiguousSpans: [...this.ambiguousSpans]
      };
    }
    state() {
      const rendered = this.renderBuffer();
      return {
        raw: this.lockedRaw + this.pendingFragment,
        output: rendered
      };
    }
    input(char) {
      this.feedChar(char);
      return this.state();
    }
    feedChar(char) {
      const whitespaceBoundary = /[\s\r\n\t]/;
      const punctuationBoundary = /[.,!?;:@*#~_|><]/;
      if (whitespaceBoundary.test(char)) {
        const rendered2 = this.renderBuffer() + char;
        const state2 = {
          buffer: this.lockedRaw + this.pendingFragment,
          rendered: rendered2,
          committed: true,
          replaceLength: this.previousRendered.length,
          raw: this.lockedRaw + this.pendingFragment,
          output: rendered2,
          lockedOutput: this.lockedOutput,
          pendingFragment: this.pendingFragment,
          ambiguousSpans: [...this.ambiguousSpans]
        };
        this.reset();
        return state2;
      }
      if (char.length !== 1) {
        return this.getState();
      }
      if (punctuationBoundary.test(char)) {
        const pendingRendered = this.renderPendingFragment(this.pendingFragment + char);
        const rendered2 = this.lockedOutput + pendingRendered;
        const state2 = {
          buffer: this.lockedRaw + this.pendingFragment + char,
          rendered: rendered2,
          committed: true,
          replaceLength: this.previousRendered.length,
          raw: this.lockedRaw + this.pendingFragment + char,
          output: rendered2,
          lockedOutput: this.lockedOutput,
          pendingFragment: this.pendingFragment,
          ambiguousSpans: [...this.ambiguousSpans]
        };
        this.reset();
        return state2;
      }
      if (this.boundaryChar && char === this.boundaryChar) {
        if (this.pendingFragment.length > 0) {
          this.commitPendingMatches("");
        }
        this.forceNextMerge = false;
        const rendered2 = this.renderBuffer();
        const state2 = {
          buffer: this.lockedRaw,
          rendered: rendered2,
          committed: false,
          replaceLength: this.previousRendered.length,
          raw: this.lockedRaw,
          output: rendered2,
          lockedOutput: this.lockedOutput,
          pendingFragment: "",
          ambiguousSpans: [...this.ambiguousSpans]
        };
        this.previousRendered = rendered2;
        return state2;
      }
      if (this.mergeChar && char === this.mergeChar) {
        this.forceNextMerge = true;
        const rendered2 = this.renderBuffer();
        const state2 = {
          buffer: this.lockedRaw + this.pendingFragment,
          rendered: rendered2,
          committed: false,
          replaceLength: this.previousRendered.length,
          raw: this.lockedRaw + this.pendingFragment,
          output: rendered2,
          lockedOutput: this.lockedOutput,
          pendingFragment: this.pendingFragment,
          ambiguousSpans: [...this.ambiguousSpans]
        };
        this.previousRendered = rendered2;
        return state2;
      }
      if (!this.pendingFragment) {
        this.pendingFragment = char;
      } else {
        const candidate = this.pendingFragment + char;
        const currentSearch = this.trie.search(this.pendingFragment);
        const candSearch = this.trie.search(candidate);
        const canExtend = candSearch.type === "exact" || candSearch.type === "prefix";
        const isCurrentAmbiguous = currentSearch.type === "exact" && currentSearch.canContinue;
        if (isCurrentAmbiguous && canExtend && this.defaultSyllableMerging === "standalone" && !this.forceNextMerge) {
          const lockedSyl = this.renderPendingFragment(this.pendingFragment);
          const startOffset = this.lockedOutput.length;
          this.lockedOutput += lockedSyl;
          this.lockedRaw += this.pendingFragment;
          this.pendingFragment = char;
          const chosen = lockedSyl + this.renderPendingFragment(char);
          const alternate = candSearch.output ?? this.renderPendingFragment(candidate);
          this.ambiguousSpans.push({
            chosen,
            alternate,
            startOffset,
            endOffset: startOffset + chosen.length,
            raw: candidate
          });
        } else if (canExtend && (this.defaultSyllableMerging === "merge" || this.forceNextMerge || currentSearch.type === "prefix")) {
          if (isCurrentAmbiguous && candSearch.type === "exact") {
            const startOffset = this.lockedOutput.length;
            const chosen = candSearch.output ?? this.renderPendingFragment(candidate);
            const alternate = (currentSearch.output ?? "") + this.renderPendingFragment(char);
            this.ambiguousSpans.push({
              chosen,
              alternate,
              startOffset,
              endOffset: startOffset + chosen.length,
              raw: candidate
            });
          }
          this.pendingFragment = candidate;
          this.forceNextMerge = false;
        } else {
          this.commitPendingMatches(char);
          this.forceNextMerge = false;
        }
        if (this.pendingFragment.length > this.maxKeyLength) {
          this.commitPendingMatches("");
        }
      }
      const rendered = this.renderBuffer();
      const state = {
        buffer: this.lockedRaw + this.pendingFragment,
        rendered,
        committed: false,
        replaceLength: this.previousRendered.length,
        raw: this.lockedRaw + this.pendingFragment,
        output: rendered,
        lockedOutput: this.lockedOutput,
        pendingFragment: this.pendingFragment,
        ambiguousSpans: [...this.ambiguousSpans]
      };
      this.previousRendered = rendered;
      return state;
    }
    backspace() {
      if (!this.pendingFragment && !this.lockedOutput) {
        return {
          buffer: "",
          rendered: "",
          committed: false,
          replaceLength: 0,
          raw: "",
          output: "",
          lockedOutput: "",
          pendingFragment: "",
          ambiguousSpans: []
        };
      }
      const previousLength = this.previousRendered.length;
      if (this.pendingFragment.length > 0) {
        this.pendingFragment = this.pendingFragment.slice(0, -1);
        const newRendered = this.renderBuffer();
        this.previousRendered = newRendered;
        return {
          buffer: this.lockedRaw + this.pendingFragment,
          rendered: newRendered,
          committed: false,
          replaceLength: previousLength,
          raw: this.lockedRaw + this.pendingFragment,
          output: newRendered,
          lockedOutput: this.lockedOutput,
          pendingFragment: this.pendingFragment,
          ambiguousSpans: [...this.ambiguousSpans]
        };
      }
      this.previousRendered = this.lockedOutput;
      return {
        buffer: this.lockedRaw,
        rendered: this.lockedOutput,
        committed: false,
        replaceLength: 0,
        raw: this.lockedRaw,
        output: this.lockedOutput,
        lockedOutput: this.lockedOutput,
        pendingFragment: "",
        ambiguousSpans: [...this.ambiguousSpans]
      };
    }
    commit() {
      const state = this.state();
      this.reset();
      return state;
    }
    commitComposition() {
      const state = this.getState();
      this.reset();
      return state;
    }
    reset() {
      this.lockedOutput = "";
      this.lockedRaw = "";
      this.pendingFragment = "";
      this.forceNextMerge = false;
      this.previousRendered = "";
      this.ambiguousSpans = [];
    }
    get raw() {
      return this.lockedRaw + this.pendingFragment;
    }
    get output() {
      return this.renderBuffer();
    }
    get locked() {
      return this.lockedOutput;
    }
    get pending() {
      return this.pendingFragment;
    }
    get ambiguities() {
      return [...this.ambiguousSpans];
    }
    commitPendingMatches(newChar) {
      let fragment = this.pendingFragment;
      while (fragment.length > 0) {
        const match = this.trie.findLongestMatch(fragment);
        if (match && match.matchedLength > 0) {
          this.lockedOutput += match.output;
          this.lockedRaw += fragment.slice(0, match.matchedLength);
          fragment = fragment.slice(match.matchedLength);
        } else {
          const charToLock = fragment[0];
          const rendered = this.renderPendingFragment(charToLock);
          this.lockedOutput += rendered;
          this.lockedRaw += charToLock;
          fragment = fragment.slice(1);
        }
      }
      this.pendingFragment = newChar;
    }
    renderPendingFragment(fragment) {
      if (!fragment) return "";
      return this.transliterator.transliterateWord(fragment);
    }
    renderBuffer() {
      return this.lockedOutput + this.renderPendingFragment(this.pendingFragment);
    }
  };

  // src/browser/landing/landing.ts
  var README_SYLLABARY_DATA = [
    { name: "Ha (\u1200)", triggers: "h", orders: ["\u1200 (ha)", "\u1201 (hu)", "\u1202 (hi)", "\u1203 (haa)", "\u1204 (he/hee)", "\u1205 (h)", "\u1206 (ho)", "\u128B (hwa)"] },
    { name: "La (\u1208)", triggers: "l", orders: ["\u1208 (le)", "\u1209 (lu)", "\u120A (li)", "\u120B (la/laa)", "\u120C (lee)", "\u120D (l)", "\u120E (lo)", "\u120F (lwa)"] },
    { name: "HHa (\u1210)", triggers: "H, hh", orders: ["\u1210 (Ha/hha)", "\u1211 (Hu/hhu)", "\u1212 (Hi/hhi)", "\u1213 (Haa/hhaa)", "\u1214 (He/hhe/Hee)", "\u1215 (H/hh)", "\u1216 (Ho/hho)", "\u1217 (Hwa/hhwa)"] },
    { name: "Ma (\u1218)", triggers: "m", orders: ["\u1218 (me)", "\u1219 (mu)", "\u121A (mi)", "\u121B (ma/maa)", "\u121C (mee)", "\u121D (m)", "\u121E (mo)", "\u121F (mwa)"] },
    { name: "SSa (\u1220)", triggers: "S, ss, s'", orders: ["\u1220 (Se/sse)", "\u1221 (Su/ssu)", "\u1222 (Si/ssi)", "\u1223 (Sa/ssa)", "\u1224 (See/ssee)", "\u1225 (S/ss)", "\u1226 (So/sso)", "\u1227 (Swa/sswa)"] },
    { name: "Ra (\u1228)", triggers: "r", orders: ["\u1228 (re)", "\u1229 (ru)", "\u122A (ri)", "\u122B (ra/raa)", "\u122C (ree)", "\u122D (r)", "\u122E (ro)", "\u122F (rwa)"] },
    { name: "Sa (\u1230)", triggers: "s", orders: ["\u1230 (se)", "\u1231 (su)", "\u1232 (si)", "\u1233 (sa/saa)", "\u1234 (see)", "\u1235 (s)", "\u1236 (so)", "\u1237 (swa)"] },
    { name: "Sha (\u1238)", triggers: "sh, Sh", orders: ["\u1238 (she)", "\u1239 (shu)", "\u123A (shi)", "\u123B (sha/shaa)", "\u123C (shee)", "\u123D (sh)", "\u123E (sho)", "\u123F (shwa)"] },
    { name: "Qa (\u1240)", triggers: "q, k', K, Q", orders: ["\u1240 (qe/Ke)", "\u1241 (qu/Ku)", "\u1242 (qi/Ki)", "\u1243 (qa/Ka)", "\u1244 (qee/Kee)", "\u1245 (q/K)", "\u1246 (qo/Ko)", "\u124B (qwa/Kwa)"] },
    { name: "Ba (\u1260)", triggers: "b", orders: ["\u1260 (be)", "\u1261 (bu)", "\u1262 (bi)", "\u1263 (ba/baa)", "\u1264 (bee)", "\u1265 (b)", "\u1266 (bo)", "\u1267 (bwa)"] },
    { name: "Va (\u1268)", triggers: "v, V, B, b'", orders: ["\u1268 (ve/Be)", "\u1269 (vu/Bu)", "\u126A (vi/Bi)", "\u126B (va/Ba)", "\u126C (vee/Bee)", "\u126D (v/B)", "\u126E (vo/Bo)", "\u126F (vwa/Bwa)"] },
    { name: "Ta (\u1270)", triggers: "t", orders: ["\u1270 (te)", "\u1271 (tu)", "\u1272 (ti)", "\u1273 (ta/taa)", "\u1274 (tee)", "\u1275 (t)", "\u1276 (to)", "\u1277 (twa)"] },
    { name: "Cha (\u1278)", triggers: "ch, c", orders: ["\u1278 (che/ce)", "\u1279 (chu/cu)", "\u127A (chi/ci)", "\u127B (cha/ca)", "\u127C (chee/cee)", "\u127D (ch/c)", "\u127E (cho/co)", "\u127F (chwa/cwa)"] },
    { name: "H'a (\u1280)", triggers: "h', xh, hx", orders: ["\u1280 (xha/h'a)", "\u1281 (xhu/h'u)", "\u1282 (xhi/h'i)", "\u1283 (xhaa/h'aa)", "\u1284 (xhe/h'e)", "\u1285 (xh/h')", "\u1286 (xho/h'o)", "\u128B (xhwa/h'wa)"] },
    { name: "Na (\u1290)", triggers: "n", orders: ["\u1290 (ne)", "\u1291 (nu)", "\u1292 (ni)", "\u1293 (na/naa)", "\u1294 (nee)", "\u1295 (n)", "\u1296 (no)", "\u1297 (nwa)"] },
    { name: "Nya (\u1298)", triggers: "ny, N, GN, n'", orders: ["\u1298 (nye/Ne)", "\u1299 (nyu/Nu)", "\u129A (nyi/Ni)", "\u129B (nya/Na)", "\u131C (nyee/Nee)", "\u129D (ny/N)", "\u129E (nyo/No)", "\u135D (nywa/Nwa)"] },
    { name: "A (\u12A0)", triggers: "a, '", orders: ["\u12A0 (a)", "\u12A1 (u)", "\u12A2 (i)", "\u12A3 (aa)", "\u12A4 (ee)", "\u12A5 (e)", "\u12A6 (o)", "\u12A7 (wa)"] },
    { name: "Ka (\u12A8)", triggers: "k", orders: ["\u12A8 (ke)", "\u12A9 (ku)", "\u12AA (ki)", "\u12AB (ka/kaa)", "\u12AC (kee)", "\u12AD (k)", "\u12AE (ko)", "\u12B3 (kwa)"] },
    { name: "KHa (\u12B8)", triggers: "kh, x, X", orders: ["\u12B8 (khe/xe)", "\u12B9 (khu/xu)", "\u12BA (khi/xi)", "\u12BB (kha/xa)", "\u12BC (khee/xee)", "\u12BD (kh/x)", "\u12BE (kho/xo)", "\u12C3 (khwa/xwa)"] },
    { name: "Wa (\u12C8)", triggers: "w", orders: ["\u12C8 (we)", "\u12C9 (wu)", "\u12CA (wi)", "\u12CB (wa/waa)", "\u12CC (wee)", "\u12CD (w)", "\u12CE (wo)", "\u2014"] },
    { name: "AHa (\u12D0)", triggers: "A, ah, a'", orders: ["\u12D0 (Aa/aha)", "\u12D1 (Au/ahu)", "\u12D2 (Ai/ahi)", "\u12D3 (Aaa/ahaa)", "\u12D4 (Ae/ahe)", "\u12D5 (A/ah)", "\u12D6 (Ao/aho)", "\u2014"] },
    { name: "Za (\u12D8)", triggers: "z", orders: ["\u12D8 (ze)", "\u12D9 (zu)", "\u12DA (zi)", "\u12DB (za)", "\u12DC (zee)", "\u12DD (z)", "\u12DE (zo)", "\u12DF (zwa)"] },
    { name: "ZHa (\u12E0)", triggers: "zh, Z, z'", orders: ["\u12E0 (zhe/Ze)", "\u12E1 (zhu/Zu)", "\u12E2 (zhi/Zi)", "\u12E3 (zha/Za)", "\u12E4 (zhee/Zee)", "\u12E5 (zh/Z)", "\u12E6 (zho/Zo)", "\u12E7 (zhwa/Zwa)"] },
    { name: "Ya (\u12E8)", triggers: "y", orders: ["\u12E8 (ye)", "\u12E9 (yu)", "\u12ED (yi)", "\u12EB (ya)", "\u12EC (yee)", "\u12ED (y)", "\u12EE (yo)", "\u2014"] },
    { name: "Da (\u12F0)", triggers: "d", orders: ["\u12F0 (de)", "\u12F1 (du)", "\u12F2 (di)", "\u12F3 (da)", "\u12F4 (dee)", "\u12F5 (d)", "\u12F6 (do)", "\u12F7 (dwa)"] },
    { name: "Ja (\u1300)", triggers: "j", orders: ["\u1300 (je)", "\u1301 (ju)", "\u1302 (ji)", "\u1303 (ja)", "\u1304 (jee)", "\u1305 (j)", "\u1306 (jo)", "\u1307 (jwa)"] },
    { name: "Ga (\u1308)", triggers: "g", orders: ["\u1308 (ge)", "\u1309 (gu)", "\u130A (gi)", "\u130B (ga)", "\u130C (gee)", "\u130D (g)", "\u130E (go)", "\u1313 (gwa)"] },
    { name: "T'a (\u1320)", triggers: "T, t'", orders: ["\u1320 (Te/t'e)", "\u1321 (Tu/t'u)", "\u1322 (Ti/t'i)", "\u1323 (Ta/t'a)", "\u1324 (Tee/t'ee)", "\u1325 (T/t')", "\u1326 (To/t'o)", "\u1327 (Twa/t'wa)"] },
    { name: "C'a (\u1328)", triggers: "C, CH, c'", orders: ["\u1328 (Ce/c'e)", "\u1329 (Cu/c'u)", "\u132A (Ci/c'i)", "\u132B (Ca/c'a)", "\u132C (Cee/c'ee)", "\u132D (C/c')", "\u132E (Co/c'o)", "\u132F (Cwa/c'wa)"] },
    { name: "P'a (\u1330)", triggers: "P, p'", orders: ["\u1330 (Pe/p'e)", "\u1331 (Pu/p'u)", "\u1332 (Pi/p'i)", "\u1333 (Pa/p'a)", "\u1334 (Pee/p'ee)", "\u1335 (P/p')", "\u1336 (Po/p'o)", "\u1337 (Pwa/p'wa)"] },
    { name: "TSa (\u1338)", triggers: "ts, Ts, Tz, S'", orders: ["\u1338 (tse)", "\u1339 (tsu)", "\u133A (tsi)", "\u133B (tsa)", "\u133C (tsee)", "\u133D (ts)", "\u133E (tso)", "\u133F (tswa)"] },
    { name: "TZa (\u1340)", triggers: "tz, TZ, ts'", orders: ["\u1340 (tze/TZe)", "\u1341 (tzu/TZu)", "\u1342 (tzi/TZi)", "\u1343 (tza/TZa)", "\u1344 (tzee/TZee)", "\u1345 (tz/TZ)", "\u1346 (tzo/TZo)", "\u2014"] },
    { name: "Fa (\u1348)", triggers: "f", orders: ["\u1348 (fe)", "\u1349 (fu)", "\u134A (fi)", "\u134B (fa)", "\u134C (fee)", "\u134D (f)", "\u134E (fo)", "\u134F (fwa)"] },
    { name: "Pa (\u1350)", triggers: "p", orders: ["\u1350 (pe)", "\u1351 (pu)", "\u1352 (pi)", "\u1353 (pa)", "\u1354 (pee)", "\u1355 (p)", "\u1356 (po)", "\u1357 (pwa)"] }
  ];
  function initLanding() {
    const themeToggle = document.getElementById("theme-toggle");
    const savedTheme = localStorage.getItem("fidel_theme") || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);
    themeToggle?.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") || "dark";
      const next = current === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem("fidel_theme", next);
    });
    const progressBar = document.getElementById("scroll-progress");
    window.addEventListener("scroll", () => {
      if (!progressBar) return;
      const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = height > 0 ? winScroll / height * 100 : 0;
      progressBar.style.width = `${scrolled}%`;
    }, { passive: true });
    const simInput = document.getElementById("sim-input");
    const simOutput = document.getElementById("sim-output");
    const simFamily = document.getElementById("sim-family");
    const sandboxInput = document.getElementById("sandbox-input");
    const sandboxRendered = document.getElementById("sandbox-rendered");
    const btnCopySandbox = document.getElementById("btn-copy-sandbox");
    const statChars = document.getElementById("stat-chars");
    const statSyllables = document.getElementById("stat-syllables");
    const matrixSearch = document.getElementById("matrix-search-input");
    const matrixTbody = document.getElementById("matrix-tbody");
    const transliterator = new Transliterator({
      convertPunctuation: true,
      convertNumbers: true,
      smartCorrection: true
    });
    const demoPhrases = [
      { text: "selam yihun", desc: "Greeting: selam yihun \u2192 \u1230\u120B\u121D \u12ED\u1201\u1295" },
      { text: "gEz qwanqwa", desc: "Geez Language: gEz qwanqwa \u2192 \u130D\u12A5\u12DD \u124B\u1295\u124B" },
      { text: "k'idus yared", desc: "Saint Yared: k'idus yared \u2192 \u1245\u12F1\u1235 \u12EB\u122C\u12F5" },
      { text: "t-e metahu", desc: "Boundary Override: t-e metahu \u2192 \u1275\u12A5 \u1218\u1323\u1201" },
      { text: "enkwan des alachu", desc: "Celebration: enkwan des alachu \u2192 \u12A5\u1295\u12B3\u1295 \u12F0\u1235 \u12A0\u120B\u1279" }
    ];
    let phraseIdx = 0;
    let charIdx = 0;
    let isDeleting = false;
    const engine = new CompositionEngine();
    function tickSimulator() {
      if (!simInput || !simOutput || !simFamily) return;
      const current = demoPhrases[phraseIdx];
      if (!isDeleting) {
        charIdx++;
        const sub = current.text.slice(0, charIdx);
        simInput.textContent = sub;
        engine.reset();
        for (const ch of sub) {
          engine.feedChar(ch);
        }
        simOutput.textContent = transliterator.transliterate(sub);
        simFamily.textContent = current.desc;
        if (charIdx === current.text.length) {
          isDeleting = true;
          setTimeout(tickSimulator, 2500);
          return;
        }
        setTimeout(tickSimulator, 110);
      } else {
        charIdx--;
        const sub = current.text.slice(0, charIdx);
        simInput.textContent = sub;
        simOutput.textContent = sub ? transliterator.transliterate(sub) : "...";
        if (charIdx === 0) {
          isDeleting = false;
          phraseIdx = (phraseIdx + 1) % demoPhrases.length;
          setTimeout(tickSimulator, 400);
          return;
        }
        setTimeout(tickSimulator, 45);
      }
    }
    tickSimulator();
    function updateSandbox() {
      if (!sandboxInput || !sandboxRendered) return;
      const text = sandboxInput.value;
      if (!text.trim()) {
        sandboxRendered.textContent = "\u1230\u120B\u121D! \u12A5\u1295\u12B3\u1295 \u12C8\u12F0 \u134A\u12F0\u120D \u1260\u1230\u120B\u121D \u1218\u1323\u1201\u1362";
        if (statChars) statChars.textContent = "0";
        if (statSyllables) statSyllables.textContent = "0";
        return;
      }
      const res = transliterator.transliterate(text);
      sandboxRendered.textContent = res;
      if (statChars) statChars.textContent = text.length.toString();
      if (statSyllables) statSyllables.textContent = res.length.toString();
    }
    sandboxInput?.addEventListener("input", updateSandbox);
    updateSandbox();
    btnCopySandbox?.addEventListener("click", async () => {
      const text = sandboxRendered?.textContent || "";
      if (text) {
        await navigator.clipboard.writeText(text);
        const span = btnCopySandbox.querySelector("span");
        if (span) span.textContent = "Copied! \u2713";
        btnCopySandbox.style.background = "#ffffff";
        btnCopySandbox.style.color = "#000000";
        setTimeout(() => {
          if (span) span.textContent = "Copy";
          btnCopySandbox.style.background = "";
          btnCopySandbox.style.color = "";
        }, 1500);
      }
    });
    function renderMatrix(filter = "") {
      if (!matrixTbody) return;
      matrixTbody.innerHTML = "";
      const q = filter.trim().toLowerCase();
      README_SYLLABARY_DATA.forEach((row) => {
        const fullText = `${row.name} ${row.triggers} ${row.orders.join(" ")}`.toLowerCase();
        if (q && !fullText.includes(q)) return;
        const tr = document.createElement("tr");
        const orderCells = row.orders.map((order) => {
          const parts = order.split(" ");
          const glyph = parts[0];
          const ph = parts.slice(1).join(" ");
          if (glyph === "\u2014") {
            return `<td><span class="matrix-dash">\u2014</span></td>`;
          }
          return `<td><button type="button" class="matrix-char-cell" data-char="${glyph}" title="Click to copy ${glyph}">
          <span class="cell-glyph">${glyph}</span>
          <span class="cell-ph">${ph}</span>
          <span class="cell-toast">Copied! \u2713</span>
        </button></td>`;
        }).join("");
        tr.innerHTML = `
        <td class="family-name-cell"><strong>${row.name}</strong></td>
        <td class="family-trigger-cell"><code>${escapeHtml(row.triggers)}</code></td>
        ${orderCells}
      `;
        matrixTbody.appendChild(tr);
      });
      matrixTbody.querySelectorAll(".matrix-char-cell").forEach((cell) => {
        cell.addEventListener("click", async (e) => {
          const targetBtn = e.currentTarget;
          const ch = targetBtn.getAttribute("data-char");
          if (ch && ch !== "\u2014") {
            await navigator.clipboard.writeText(ch);
            targetBtn.classList.add("copied");
            setTimeout(() => {
              targetBtn.classList.remove("copied");
            }, 1200);
            if (matrixSearch) {
              const originalPlaceholder = matrixSearch.placeholder;
              matrixSearch.placeholder = `Copied "${ch}" to clipboard!`;
              setTimeout(() => {
                matrixSearch.placeholder = originalPlaceholder;
              }, 1800);
            }
          }
        });
      });
    }
    function escapeHtml(str) {
      return str.replace(/[&<>"']/g, (m) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      })[m] || m);
    }
    matrixSearch?.addEventListener("input", () => {
      renderMatrix(matrixSearch.value);
    });
    renderMatrix();
    document.querySelectorAll(".btn-copy-snippet").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const code = btn.getAttribute("data-copy");
        if (code) {
          await navigator.clipboard.writeText(code);
          btn.innerHTML = '<span style="font-size:11px;font-weight:700;">Copied! \u2713</span>';
          setTimeout(() => {
            btn.innerHTML = '<svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
          }, 1500);
        }
      });
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLanding);
  } else {
    initLanding();
  }
})();
//# sourceMappingURL=landing.js.map
