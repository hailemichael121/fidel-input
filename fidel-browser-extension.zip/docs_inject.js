"use strict";
(() => {
  // src/browser/content/docs_inject.ts
  (function initDocsForceHtml() {
    try {
      window._docs_force_html_by_ext = "fidel-extension";
      document.documentElement.setAttribute("data-docs-force-html", "true");
    } catch {
    }
  })();
})();
