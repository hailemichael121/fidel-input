"use strict";
(() => {
  // src/browser/storage/types.ts
  var DEFAULT_SETTINGS = {
    enabled: true,
    convertPunctuation: true,
    convertNumbers: true,
    smartCorrection: true,
    suggestions: true,
    defaultSyllableMerging: "merge",
    compositionBoundaryChar: "-",
    compositionMergeChar: "+",
    dictionary: {},
    disabledDomains: []
  };

  // src/browser/storage/storageAdapter.ts
  var BrowserStorageAdapter = class {
    static STORAGE_KEY = "fidel_browser_settings";
    static async getSettings() {
      if (typeof chrome === "undefined" || !chrome.storage) {
        return DEFAULT_SETTINGS;
      }
      return new Promise((resolve) => {
        chrome.storage.sync.get([this.STORAGE_KEY], (result) => {
          if (chrome.runtime.lastError || !result[this.STORAGE_KEY]) {
            chrome.storage.local.get([this.STORAGE_KEY], (localResult) => {
              const localData = localResult?.[this.STORAGE_KEY] || {};
              resolve({ ...DEFAULT_SETTINGS, ...localData });
            });
          } else {
            const syncData = result?.[this.STORAGE_KEY] || {};
            resolve({ ...DEFAULT_SETTINGS, ...syncData });
          }
        });
      });
    }
    static async saveSettings(settings) {
      const current = await this.getSettings();
      const updated = { ...current, ...settings };
      if (typeof chrome !== "undefined" && chrome.storage) {
        await new Promise((resolve) => {
          chrome.storage.sync.set({ [this.STORAGE_KEY]: updated }, () => {
            if (chrome.runtime.lastError) {
              chrome.storage.local.set({ [this.STORAGE_KEY]: updated }, () => resolve());
            } else {
              chrome.storage.local.set({ [this.STORAGE_KEY]: updated }, () => resolve());
            }
          });
        });
      }
      return updated;
    }
    static onSettingsChange(callback) {
      if (typeof chrome === "undefined" || !chrome.storage) return;
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if ((areaName === "sync" || areaName === "local") && changes[this.STORAGE_KEY]) {
          const newValue = changes[this.STORAGE_KEY].newValue;
          if (newValue) {
            callback({ ...DEFAULT_SETTINGS, ...newValue });
          }
        }
      });
    }
  };

  // src/engine/mapping.ts
  var FIDEL_FAMILIES = {
    // h (ሀ)
    h: { e: "\u1200", u: "\u1201", i: "\u1202", a: "\u1203", ee: "\u1204", "": "\u1205", o: "\u1206", wa: "\u128B" },
    // l (ለ)
    l: { e: "\u1208", u: "\u1209", i: "\u120A", a: "\u120B", ee: "\u120C", "": "\u120D", o: "\u120E", wa: "\u120F" },
    // H / hh (ሐ)
    H: { e: "\u1210", u: "\u1211", i: "\u1212", a: "\u1213", ee: "\u1214", "": "\u1215", o: "\u1216", wa: "\u1217" },
    hh: { e: "\u1210", u: "\u1211", i: "\u1212", a: "\u1213", ee: "\u1214", "": "\u1215", o: "\u1216", wa: "\u1217" },
    // m (መ)
    m: { e: "\u1218", u: "\u1219", i: "\u121A", a: "\u121B", ee: "\u121C", "": "\u121D", o: "\u121E", wa: "\u121F" },
    // ss / S / s' (ሠ)
    ss: { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    S: { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    "s'": { e: "\u1220", u: "\u1221", i: "\u1222", a: "\u1223", ee: "\u1224", "": "\u1225", o: "\u1226", wa: "\u1227" },
    // r (ረ)
    r: { e: "\u1228", u: "\u1229", i: "\u122A", a: "\u122B", ee: "\u122C", "": "\u122D", o: "\u122E", wa: "\u122F" },
    // s (ሰ)
    s: { e: "\u1230", u: "\u1231", i: "\u1232", a: "\u1233", ee: "\u1234", "": "\u1235", o: "\u1236", wa: "\u1237" },
    // sh (ሸ)
    sh: { e: "\u1238", u: "\u1239", i: "\u123A", a: "\u123B", ee: "\u123C", "": "\u123D", o: "\u123E", wa: "\u123F" },
    // q / k' / K / Q (ቀ)
    q: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    "k'": { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    K: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    Q: { e: "\u1240", u: "\u1241", i: "\u1242", a: "\u1243", ee: "\u1244", "": "\u1245", o: "\u1246", wa: "\u124B" },
    // b (በ)
    b: { e: "\u1260", u: "\u1261", i: "\u1262", a: "\u1263", ee: "\u1264", "": "\u1265", o: "\u1266", wa: "\u1267" },
    // v / V / B / b' (ቨ)
    v: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    V: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    B: { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    "b'": { e: "\u1268", u: "\u1269", i: "\u126A", a: "\u126B", ee: "\u126C", "": "\u126D", o: "\u126E", wa: "\u126F" },
    // t (ተ)
    t: { e: "\u1270", u: "\u1271", i: "\u1272", a: "\u1273", ee: "\u1274", "": "\u1275", o: "\u1276", wa: "\u1277" },
    // ch / c (ቸ)
    ch: { e: "\u1278", u: "\u1279", i: "\u127A", a: "\u127B", ee: "\u127C", "": "\u127D", o: "\u127E", wa: "\u127F" },
    c: { e: "\u1278", u: "\u1279", i: "\u127A", a: "\u127B", ee: "\u127C", "": "\u127D", o: "\u127E", wa: "\u127F" },
    // h' / xh / hx (ኀ)
    "h'": { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    xh: { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    hx: { e: "\u1280", u: "\u1281", i: "\u1282", a: "\u1283", ee: "\u1284", "": "\u1285", o: "\u1286", wa: "\u128B" },
    // n (ነ)
    n: { e: "\u1290", u: "\u1291", i: "\u1292", a: "\u1293", ee: "\u1294", "": "\u1295", o: "\u1296", wa: "\u1297" },
    // ny / GN / N / n' (ኘ)
    ny: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    GN: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    N: { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    "n'": { e: "\u1298", u: "\u1299", i: "\u129A", a: "\u129B", ee: "\u129C", "": "\u129D", o: "\u129E", wa: "\u129F" },
    // ' / ea (አ - Alef consonant family)
    "'": { e: "\u12A0", u: "\u12A1", i: "\u12A2", a: "\u12A3", ee: "\u12A4", "": "\u12A5", o: "\u12A6", wa: "\u12A7" },
    ea: { e: "\u12A0", u: "\u12A1", i: "\u12A2", a: "\u12A3", ee: "\u12A4", "": "\u12A0", o: "\u12A6", wa: "\u12A7" },
    // k (ከ)
    k: { e: "\u12A8", u: "\u12A9", i: "\u12AA", a: "\u12AB", ee: "\u12AC", "": "\u12AD", o: "\u12AE", wa: "\u12B3" },
    // kh / x / X (ኸ)
    kh: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    x: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    X: { e: "\u12B8", u: "\u12B9", i: "\u12BA", a: "\u12BB", ee: "\u12BC", "": "\u12BD", o: "\u12BE", wa: "\u12C3" },
    // w (ወ)
    w: { e: "\u12C8", u: "\u12C9", i: "\u12CA", a: "\u12CB", ee: "\u12CC", "": "\u12CD", o: "\u12CE" },
    // ah / A / a' (ዐ)
    ah: { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    A: { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    "a'": { e: "\u12D0", u: "\u12D1", i: "\u12D2", a: "\u12D3", ee: "\u12D4", "": "\u12D5", o: "\u12D6" },
    // z (ዘ)
    z: { e: "\u12D8", u: "\u12D9", i: "\u12DA", a: "\u12DB", ee: "\u12DC", "": "\u12DD", o: "\u12DE", wa: "\u12DF" },
    // zh / Z / z' (ዠ)
    zh: { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    Z: { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    "z'": { e: "\u12E0", u: "\u12E1", i: "\u12E2", a: "\u12E3", ee: "\u12E4", "": "\u12E5", o: "\u12E6", wa: "\u12E7" },
    // y (የ)
    y: { e: "\u12E8", u: "\u12E9", i: "\u12ED", a: "\u12EB", ee: "\u12EC", "": "\u12ED", o: "\u12EE" },
    // d (ደ)
    d: { e: "\u12F0", u: "\u12F1", i: "\u12F2", a: "\u12F3", ee: "\u12F4", "": "\u12F5", o: "\u12F6", wa: "\u12F7" },
    // j (ጀ)
    j: { e: "\u1300", u: "\u1301", i: "\u1302", a: "\u1303", ee: "\u1304", "": "\u1305", o: "\u1306", wa: "\u1307" },
    // g (ገ)
    g: { e: "\u1308", u: "\u1309", i: "\u130A", a: "\u130B", ee: "\u130C", "": "\u130D", o: "\u130E", wa: "\u1313" },
    // t' / T (ጠ)
    "t'": { e: "\u1320", u: "\u1321", i: "\u1322", a: "\u1323", ee: "\u1324", "": "\u1325", o: "\u1326", wa: "\u1327" },
    T: { e: "\u1320", u: "\u1321", i: "\u1322", a: "\u1323", ee: "\u1324", "": "\u1325", o: "\u1326", wa: "\u1327" },
    // c' / CH / C (ጨ)
    "c'": { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    CH: { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    C: { e: "\u1328", u: "\u1329", i: "\u132A", a: "\u132B", ee: "\u132C", "": "\u132D", o: "\u132E", wa: "\u132F" },
    // p' / P (ጰ)
    "p'": { e: "\u1330", u: "\u1331", i: "\u1332", a: "\u1333", ee: "\u1334", "": "\u1335", o: "\u1336", wa: "\u1337" },
    P: { e: "\u1330", u: "\u1331", i: "\u1332", a: "\u1333", ee: "\u1334", "": "\u1335", o: "\u1336", wa: "\u1337" },
    // ts / tz / Tz / S' / Ts / ts' (ጸ / ፀ)
    ts: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    Ts: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    Tz: { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    "S'": { e: "\u1338", u: "\u1339", i: "\u133A", a: "\u133B", ee: "\u133C", "": "\u133D", o: "\u133E", wa: "\u133F" },
    tz: { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    TZ: { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    "ts'": { e: "\u1340", u: "\u1341", i: "\u1342", a: "\u1343", ee: "\u1344", "": "\u1345", o: "\u1346" },
    // f (ፈ)
    f: { e: "\u1348", u: "\u1349", i: "\u134A", a: "\u134B", ee: "\u134C", "": "\u134D", o: "\u134E", wa: "\u134F" },
    // p (ፐ)
    p: { e: "\u1350", u: "\u1351", i: "\u1352", a: "\u1353", ee: "\u1354", "": "\u1355", o: "\u1356", wa: "\u1357" }
  };
  var PUNCTUATION_MAP = {
    // 1. Distinct 1-to-1 Keyboard Triggers
    ".": "\u1362",
    // Ethiopic Full Stop / Arat Neteb (አራት ነጥብ)
    ",": "\u1363",
    // Ethiopic Comma / Netela Serez (ነጠላ ሰረዝ)
    ";": "\u1364",
    // Ethiopic Semicolon / Derb Serez (ድርብ ሰረዝ)
    ":": "\u1361",
    // Ethiopic Wordspace / Hulat Neteb (ሁለት ነጥብ)
    "?": "\u1367",
    // Ethiopic Question Mark / Yimer (ይመር)
    "|": "\u1365",
    // Ethiopic Colon / Sost Neteb (ሦስት ነጥብ / አንቀጽ)
    ">": "\u1366",
    // Ethiopic Preface Colon / Meqereya (መቅረዝ)
    "@": "\u1360",
    // Ethiopic Section Mark / Ayne T'ila (ዓይነ ጥላ)
    "#": "\u1368",
    // Ethiopic Paragraph Separator / Yieti (ይእቲ)
    "~": "\u135F",
    // Ethiopic Combining Gemination Mark / T'ebiq (ጥብቅ)
    // 2. Multi-character & Shorthand Aliases
    "::": "\u1362",
    // Arat Neteb alias
    "..": "\u1362",
    // Arat Neteb alias
    ",,": "\u1364",
    // Derb Serez alias
    ":-": "\u1365",
    // Sost Neteb alias
    ":-:": "\u1366",
    // Meqereya alias
    ":::": "\u1366",
    // Meqereya alias
    "*": "\u1360",
    // Ayne T'ila alias
    "@@": "\u1360",
    // Ayne T'ila alias
    "**": "\u1368",
    // Yieti alias
    "***": "\u1368",
    // Yieti alias
    "##": "\u1368",
    // Yieti alias
    "_": "\u135F"
    // Gemination Mark alias
  };
  var COMMON_WORD_MAP = {
    // Common greetings & expressions
    selam: "\u1230\u120B\u121D",
    endemin: "\u12A5\u1295\u12F0\u121D\u1295",
    tena: "\u1324\u1293",
    tenayistillign: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    tenayistilign: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    tenayistilln: "\u1324\u1293\u12ED\u1235\u1325\u120D\u129D",
    ameseginalehu: "\u12A0\u1218\u1230\u130D\u1293\u1208\u1201",
    amesegenalehu: "\u12A0\u1218\u1230\u130D\u1293\u1208\u1201",
    dehna: "\u12F0\u1205\u1293",
    ishii: "\u12A5\u123A",
    ishi: "\u12A5\u123A",
    awo: "\u12A0\u12CE",
    yellem: "\u12E8\u1208\u121D",
    yelem: "\u12E8\u1208\u121D",
    // Family & Relationships
    enat: "\u12A5\u1293\u1275",
    abat: "\u12A0\u1263\u1275",
    wendim: "\u12C8\u1295\u12F5\u121D",
    ihit: "\u12A5\u1205\u1275",
    lij: "\u120D\u1305",
    lijoch: "\u120D\u1306\u127D",
    wodaj: "\u12C8\u12F3\u1305",
    gwad: "\u1313\u12F5",
    // Places & Country
    ethiopia: "\u12A2\u1275\u12EE\u1335\u12EB",
    ityopya: "\u12A2\u1275\u12EE\u1335\u12EB",
    "ityop'ya": "\u12A2\u1275\u12EE\u1335\u12EB",
    ethiopian: "\u12A2\u1275\u12EE\u1335\u12EB\u12CA",
    amharic: "\u12A0\u121B\u122D\u129B",
    amaric: "\u12A0\u121B\u122D\u129B",
    amharik: "\u12A0\u121B\u122D\u129B",
    fidel: "\u134A\u12F0\u120D",
    addis: "\u12A0\u12F2\u1235",
    adis: "\u12A0\u12F2\u1235",
    ababa: "\u12A0\u1260\u1263",
    abeba: "\u12A0\u1260\u1263",
    addisababa: "\u12A0\u12F2\u1235 \u12A0\u1260\u1263",
    addisabeba: "\u12A0\u12F2\u1235 \u12A0\u1260\u1263",
    amhara: "\u12A0\u121B\u122B",
    oromia: "\u12A6\u122E\u121A\u12EB",
    tigray: "\u1275\u130D\u122B\u12ED",
    habesha: "\u1200\u1260\u123B",
    // Religious & Cultural Names / Terms
    egziabher: "\u12A5\u130D\u12DA\u12A0\u1265\u1214\u122D",
    igziabher: "\u12A5\u130D\u12DA\u12A0\u1265\u1214\u122D",
    mariam: "\u121B\u122A\u12EB\u121D",
    maryam: "\u121B\u122A\u12EB\u121D",
    mikael: "\u121A\u12AB\u12A4\u120D",
    michael: "\u121A\u12AB\u12A4\u120D",
    gebriel: "\u1308\u1265\u122D\u12A4\u120D",
    gabriel: "\u1308\u1265\u122D\u12A4\u120D",
    // Common Amharic Personal Names
    abebe: "\u12A0\u1260\u1260",
    bet: "\u1264\u1275",
    beet: "\u1264\u1275",
    yihun: "\u12ED\u1201\u1295",
    haile: "\u1283\u12ED\u1208",
    hayle: "\u1283\u12ED\u1208",
    hailemichael: "\u1283\u12ED\u1208\u121A\u12AB\u12A4\u120D",
    haylemikael: "\u1283\u12ED\u1208\u121A\u12AB\u12A4\u120D",
    haileselassie: "\u1283\u12ED\u1208\u1225\u120B\u1234",
    hayleselassie: "\u1283\u12ED\u1208\u1225\u120B\u1234",
    shekuri: "\u1238\u12A9\u122A",
    dawit: "\u12F3\u12CA\u1275",
    dawiit: "\u12F3\u12CA\u1275",
    solomon: "\u1230\u1208\u121E\u1295",
    yohannes: "\u12EE\u1210\u1295\u1235",
    tesfaye: "\u1270\u1235\u134B\u12EC",
    worku: "\u12C8\u122D\u1241",
    berhanu: "\u1265\u122D\u1203\u1291",
    girma: "\u130D\u122D\u121B",
    getachew: "\u130C\u1273\u1278\u12CD",
    tadesse: "\u1273\u12F0\u1230",
    tadese: "\u1273\u12F0\u1230",
    kebede: "\u12A8\u1260\u12F0",
    bekele: "\u1260\u1240\u1208",
    mulugeta: "\u1219\u1209\u130C\u1273",
    mulu: "\u1219\u1209",
    almaz: "\u12A0\u120D\u121B\u12DD",
    aster: "\u12A0\u1235\u1274\u122D",
    genet: "\u1308\u1290\u1275",
    tigist: "\u1275\u12D5\u130D\u1225\u1275",
    meseret: "\u1218\u1220\u1228\u1275",
    helen: "\u1214\u1208\u1295",
    amanuel: "\u12A0\u121B\u1291\u12A4\u120D",
    kifle: "\u12AD\u134D\u120C",
    // Titles & Common Nouns
    ato: "\u12A0\u1276",
    woizero: "\u12C8\u12ED\u12D8\u122E",
    weyzerit: "\u12C8\u12ED\u12D8\u122A\u1275",
    timhirt: "\u1275\u121D\u1205\u122D\u1275",
    timhirtbet: "\u1275\u121D\u1205\u122D\u1275 \u1264\u1275",
    sira: "\u1225\u122B",
    wuha: "\u12CD\u1203",
    wuhah: "\u12CD\u1203",
    beso: "\u1260\u1236",
    bela: "\u1260\u120B",
    mewad: "\u1218\u12CB\u12F5"
  };
  function buildFlatMapping() {
    const map = {};
    const H_FAMILY_PREFIXES = /* @__PURE__ */ new Set([
      "h",
      "H",
      "hh",
      "h'",
      "xh",
      "hx",
      "ah",
      "A",
      "a'"
    ]);
    const STANDALONE_VOWEL_PREFIXES = /* @__PURE__ */ new Set(["a", "e", "E", "i", "u", "o"]);
    for (const [prefix, family] of Object.entries(FIDEL_FAMILIES)) {
      if (STANDALONE_VOWEL_PREFIXES.has(prefix)) continue;
      map[prefix] = family[""];
      if (H_FAMILY_PREFIXES.has(prefix)) {
        map[prefix + "a"] = family.e;
        map[prefix + "aa"] = family.a;
        map[prefix + "e"] = family.ee;
        map[prefix + "ee"] = family.ee;
        map[prefix + "ie"] = family.ee;
      } else {
        map[prefix + "e"] = family.e;
        map[prefix + "a"] = family.a;
        map[prefix + "ee"] = family.ee;
        map[prefix + "ie"] = family.ee;
      }
      map[prefix + "u"] = family.u;
      map[prefix + "i"] = family.i;
      map[prefix + "o"] = family.o;
      if (family.wa) {
        map[prefix + "w"] = family.wa;
      }
    }
    for (const [prefix, family] of Object.entries(FIDEL_FAMILIES)) {
      if (STANDALONE_VOWEL_PREFIXES.has(prefix)) continue;
      const titlePrefix = prefix.length > 0 ? prefix[0].toUpperCase() + prefix.slice(1).toLowerCase() : prefix;
      const upperPrefix = prefix.toUpperCase();
      const variants = [titlePrefix, upperPrefix];
      const isHFamily = H_FAMILY_PREFIXES.has(prefix);
      const aTarget = isHFamily ? family.e : family.a;
      const eTarget = isHFamily ? family.ee : family.e;
      const suffixEntries = [
        ["", family[""]],
        ["e", eTarget],
        ["a", aTarget],
        ["u", family.u],
        ["i", family.i],
        ...isHFamily ? [["aa", family.a]] : [],
        ["ee", family.ee],
        ["ie", family.ee],
        ["o", family.o],
        ["w", family.wa]
      ];
      for (const vPrefix of variants) {
        for (const [suf, target] of suffixEntries) {
          if (!target) continue;
          const key = vPrefix + suf;
          if (map[key] === void 0) {
            map[key] = target;
          }
        }
      }
    }
    const standaloneVowels = [
      // 6th order standalone (እ)
      ["e", "\u12A5"],
      ["E", "\u12A5"],
      // 5th order standalone (ኤ)
      ["ee", "\u12A4"],
      ["EE", "\u12A4"],
      ["Ee", "\u12A4"],
      ["eE", "\u12A4"],
      ["ie", "\u12A4"],
      ["IE", "\u12A4"],
      ["Ie", "\u12A4"],
      // 1st order standalone (አ)
      ["a", "\u12A0"],
      ["ea", "\u12A0"],
      // 4th order standalone (ኣ)
      ["aa", "\u12A3"],
      ["AA", "\u12A3"],
      // 2nd order standalone (ኡ)
      ["u", "\u12A1"],
      ["uu", "\u12A1"],
      ["U", "\u12A1"],
      ["UU", "\u12A1"],
      // 3rd order standalone (ኢ)
      ["i", "\u12A2"],
      ["ii", "\u12A2"],
      ["I", "\u12A2"],
      ["II", "\u12A2"],
      // 7th order standalone (ኦ)
      ["o", "\u12A6"],
      ["oo", "\u12A6"],
      ["O", "\u12A6"],
      ["OO", "\u12A6"]
    ];
    for (const [vKey, vVal] of standaloneVowels) {
      map[vKey] = vVal;
    }
    for (const [word, ethiopic] of Object.entries(COMMON_WORD_MAP)) {
      map[word] = ethiopic;
      map[word.toLowerCase()] = ethiopic;
      map[word.toUpperCase()] = ethiopic;
      if (word.length > 0) {
        map[word[0].toUpperCase() + word.slice(1).toLowerCase()] = ethiopic;
      }
    }
    return map;
  }

  // src/engine/trie.ts
  var TrieNode = class {
    children = /* @__PURE__ */ new Map();
    ethiopic;
    isEnd = false;
    output = null;
  };
  var sharedRoot = null;
  var FidelTrie = class {
    root;
    constructor() {
      if (!sharedRoot) {
        sharedRoot = new TrieNode();
        this.root = sharedRoot;
        this.init();
      } else {
        this.root = sharedRoot;
      }
    }
    static resetSharedRoot() {
      sharedRoot = null;
    }
    init() {
      const flatMap = buildFlatMapping();
      for (const [latin, ethiopic] of Object.entries(flatMap)) {
        this.insert(latin, ethiopic);
      }
    }
    insert(latin, ethiopic) {
      let targetOutput = ethiopic;
      let sequence = latin;
      if (typeof latin === "object" && latin.input) {
        sequence = latin.input;
        targetOutput = latin.output;
      }
      let current = this.root;
      for (let i = 0; i < sequence.length; i++) {
        const char = sequence[i];
        if (!current.children.has(char)) {
          current.children.set(char, new TrieNode());
        }
        current = current.children.get(char);
      }
      current.ethiopic = targetOutput;
      current.output = targetOutput || null;
      current.isEnd = true;
    }
    search(latin) {
      if (!latin) {
        return { type: "none" };
      }
      let current = this.root;
      for (let i = 0; i < latin.length; i++) {
        const char = latin[i];
        if (!current.children.has(char)) {
          return { type: "none" };
        }
        current = current.children.get(char);
      }
      if (current.isEnd && current.ethiopic) {
        const canContinue = current.children.size > 0;
        return {
          type: "exact",
          output: current.ethiopic,
          matchedLength: latin.length,
          canContinue
        };
      }
      if (current.children.size > 0) {
        return { type: "prefix" };
      }
      return { type: "none" };
    }
    findLongestMatch(latin) {
      let current = this.root;
      let lastMatch = null;
      for (let i = 0; i < latin.length; i++) {
        const char = latin[i];
        if (!current.children.has(char)) {
          break;
        }
        current = current.children.get(char);
        if (current.isEnd && current.output) {
          lastMatch = {
            output: current.output,
            matchedLength: i + 1
          };
        }
      }
      return lastMatch;
    }
    match(input, offset = 0) {
      const remaining = input.slice(offset);
      const result = this.findLongestMatch(remaining);
      if (!result) return null;
      return {
        output: result.output,
        consumed: result.matchedLength,
        terminal: false
      };
    }
  };

  // src/engine/numbers.ts
  var ETHIOPIC_DIGITS = {
    "1": "\u1369",
    "2": "\u136A",
    "3": "\u136B",
    "4": "\u136C",
    "5": "\u136D",
    "6": "\u136E",
    "7": "\u136F",
    "8": "\u1370",
    "9": "\u1371"
  };
  var ETHIOPIC_TENS = {
    "10": "\u1372",
    "20": "\u1373",
    "30": "\u1374",
    "40": "\u1375",
    "50": "\u1376",
    "60": "\u1377",
    "70": "\u1378",
    "80": "\u1379",
    "90": "\u137A"
  };
  var HUNDRED = "\u137B";
  var TEN_THOUSAND = "\u137C";
  function convertNumberToEthiopic(numStr) {
    const sanitized = numStr.replace(/^0+/, "");
    if (!sanitized) {
      return numStr === "0" ? "0" : numStr;
    }
    const num = parseInt(sanitized, 10);
    if (isNaN(num) || num <= 0) {
      return numStr;
    }
    if (num < 10) {
      return ETHIOPIC_DIGITS[sanitized] || numStr;
    }
    if (num < 100) {
      const tens = Math.floor(num / 10) * 10;
      const ones = num % 10;
      let res2 = "";
      if (tens > 0 && ETHIOPIC_TENS[tens.toString()]) {
        res2 += ETHIOPIC_TENS[tens.toString()];
      }
      if (ones > 0 && ETHIOPIC_DIGITS[ones.toString()]) {
        res2 += ETHIOPIC_DIGITS[ones.toString()];
      }
      return res2;
    }
    if (num < 1e4) {
      const hundreds = Math.floor(num / 100);
      const remainder2 = num % 100;
      let res2 = "";
      if (hundreds > 0) {
        const hundredPrefix = convertNumberToEthiopic(hundreds.toString());
        if (hundredPrefix === "\u1369") {
          res2 += HUNDRED;
        } else {
          res2 += hundredPrefix + HUNDRED;
        }
      }
      if (remainder2 > 0) {
        res2 += convertNumberToEthiopic(remainder2.toString());
      }
      return res2;
    }
    const myriads = Math.floor(num / 1e4);
    const remainder = num % 1e4;
    let res = "";
    if (myriads > 0) {
      const myriadPrefix = convertNumberToEthiopic(myriads.toString());
      if (myriadPrefix === "\u1369") {
        res += TEN_THOUSAND;
      } else {
        res += myriadPrefix + TEN_THOUSAND;
      }
    }
    if (remainder > 0) {
      res += convertNumberToEthiopic(remainder.toString());
    }
    return res;
  }
  function convertNumbersInText(text, enabled) {
    if (!enabled) {
      return text;
    }
    return text.replace(/\b\d+\b/g, (match) => {
      return convertNumberToEthiopic(match);
    });
  }

  // src/engine/dictionary.ts
  var PersonalDictionary = class {
    entries = /* @__PURE__ */ new Map();
    constructor(initialEntries) {
      if (initialEntries) {
        this.setEntries(initialEntries);
      }
    }
    addEntry(latin, ethiopic) {
      if (!latin || !ethiopic) {
        return;
      }
      const key = latin.trim().toLowerCase();
      this.entries.set(key, ethiopic.trim());
    }
    removeEntry(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.delete(key);
    }
    get(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.get(key) ?? null;
    }
    has(latin) {
      const key = latin.trim().toLowerCase();
      return this.entries.has(key);
    }
    setEntries(records) {
      this.entries.clear();
      for (const [key, val] of Object.entries(records)) {
        if (key && val) {
          this.entries.set(key.trim().toLowerCase(), val.trim());
        }
      }
    }
    getEntries() {
      const result = {};
      for (const [key, val] of this.entries.entries()) {
        result[key] = val;
      }
      return result;
    }
    clear() {
      this.entries.clear();
    }
  };

  // src/engine/corrector.ts
  var SmartCorrector = class {
    /**
     * Generates candidate normalized phonetic spellings for non-standard inputs.
     * e.g., "selamm" -> "selam", "yihunn" -> "yihun", "beett" -> "bet", "amhariph" -> "amharif"
     */
    normalizeInput(input) {
      if (!input || input.length < 3) {
        return [input];
      }
      const candidates = [input];
      const collapsedTrailing = input.replace(/(.)\1+$/, "$1");
      if (collapsedTrailing !== input) {
        candidates.push(collapsedTrailing);
      }
      const collapsedAll = input.replace(/(.)\1+/g, "$1");
      if (collapsedAll !== input && !candidates.includes(collapsedAll)) {
        candidates.push(collapsedAll);
      }
      if (input.includes("ph")) {
        const phSubbed = input.replace(/ph/g, "f");
        if (!candidates.includes(phSubbed)) {
          candidates.push(phSubbed);
        }
      }
      if (input.includes("ck")) {
        const ckSubbed = input.replace(/ck/g, "k");
        if (!candidates.includes(ckSubbed)) {
          candidates.push(ckSubbed);
        }
      }
      return candidates;
    }
    /**
     * Attempts to correct a non-standard input word using candidate normalizations
     * and a provided lookup function.
     */
    correctWord(input, lookupFn) {
      const candidates = this.normalizeInput(input);
      for (const cand of candidates) {
        const match = lookupFn(cand);
        if (match) {
          return match;
        }
      }
      return null;
    }
  };

  // src/engine/transliterator.ts
  var DEFAULT_OPTIONS = {
    caseSensitive: true,
    convertPunctuation: false,
    convertNumbers: false,
    dictionary: {},
    smartCorrection: false,
    suggestions: false,
    language: "amharic"
  };
  var Transliterator = class _Transliterator {
    trie = new FidelTrie();
    options;
    dictionary;
    corrector = new SmartCorrector();
    constructor(options = {}) {
      this.options = {
        ...DEFAULT_OPTIONS,
        ...options
      };
      this.dictionary = new PersonalDictionary(this.options.dictionary);
    }
    transliterate(input) {
      if (!input) {
        return "";
      }
      const dictMatch = this.dictionary.get(input);
      if (dictMatch) {
        return dictMatch;
      }
      if (this.options.convertNumbers) {
        input = convertNumbersInText(input, true);
      }
      const commonWord = this.lookupCommonWord(input);
      if (commonWord) {
        return commonWord;
      }
      if (this.options.smartCorrection && input.length > 2) {
        const candidates = this.corrector.normalizeInput(input);
        for (const cand of candidates) {
          if (cand !== input) {
            const dictCand = this.dictionary.get(cand);
            if (dictCand) return dictCand;
            const commonCand = this.lookupCommonWord(cand);
            if (commonCand) return commonCand;
          }
        }
      }
      const output = this.matchTrie(input);
      if (this.options.smartCorrection && input.length > 2 && /[a-zA-Z]/.test(output)) {
        const candidates = this.corrector.normalizeInput(input);
        for (const cand of candidates) {
          if (cand !== input) {
            const candResult = this.matchTrie(cand);
            if (candResult && candResult !== cand && !/[a-zA-Z]/.test(candResult)) {
              if (/[a-zA-Z]/.test(output) || output !== candResult) {
                return candResult;
              }
            }
          }
        }
      }
      return output;
    }
    transliterateWord(input) {
      return this.transliterate(input);
    }
    // FIXED: No more infinite recursion!
    transliterateText(text, options) {
      if (options) {
        const opts = { ...this.options, ...options };
        const instance = new _Transliterator(opts);
        const parts2 = text.split(/(\s+)/);
        const result2 = parts2.map((part) => {
          if (part.trim().length === 0) {
            return part;
          }
          return instance.transliterate(part);
        }).join("");
        return result2;
      }
      const parts = text.split(/(\s+)/);
      const result = parts.map((part) => {
        if (part.trim().length === 0) {
          return part;
        }
        return this.transliterate(part);
      }).join("");
      return result;
    }
    matchAt(input, offset) {
      const source = this.options.caseSensitive ? input : input.toLowerCase();
      return this.findMatch(source, offset);
    }
    matchTrie(input) {
      const source = this.options.caseSensitive ? input : input.toLowerCase();
      let output = "";
      let offset = 0;
      while (offset < source.length) {
        if (this.options.convertPunctuation) {
          if (offset + 3 <= source.length) {
            const tripleChar = source.slice(offset, offset + 3);
            if (PUNCTUATION_MAP[tripleChar]) {
              output += PUNCTUATION_MAP[tripleChar];
              offset += 3;
              continue;
            }
          }
          if (offset + 2 <= source.length) {
            const doubleChar = source.slice(offset, offset + 2);
            if (PUNCTUATION_MAP[doubleChar]) {
              output += PUNCTUATION_MAP[doubleChar];
              offset += 2;
              continue;
            }
          }
        }
        const match = this.findMatch(source, offset);
        if (match) {
          output += match.output;
          offset += match.consumed;
          continue;
        }
        const character = input[offset];
        if (this.options.convertPunctuation && PUNCTUATION_MAP[character]) {
          output += PUNCTUATION_MAP[character];
        } else {
          output += character;
        }
        offset += 1;
      }
      return output;
    }
    findMatch(source, offset) {
      return this.trie.match(source, offset);
    }
    lookupCommonWord(input) {
      return COMMON_WORD_MAP[input] ?? COMMON_WORD_MAP[input.toLowerCase()] ?? null;
    }
  };

  // src/browser/popup/popup.ts
  document.addEventListener("DOMContentLoaded", async () => {
    const toggleEnabled = document.getElementById("toggle-enabled");
    const statusBanner = document.getElementById("status-banner");
    const statusLabel = document.getElementById("status-label");
    const quickInput = document.getElementById("quick-input");
    const quickOutput = document.getElementById("quick-output");
    const btnCopy = document.getElementById("btn-copy");
    const optNumbers = document.getElementById("opt-numbers");
    const optPunctuation = document.getElementById("opt-punctuation");
    const optCorrector = document.getElementById("opt-corrector");
    let currentSettings = await BrowserStorageAdapter.getSettings();
    let transliterator = new Transliterator({
      convertPunctuation: currentSettings.convertPunctuation,
      convertNumbers: currentSettings.convertNumbers,
      smartCorrection: currentSettings.smartCorrection,
      dictionary: currentSettings.dictionary
    });
    function updateUi(settings) {
      currentSettings = settings;
      toggleEnabled.checked = settings.enabled;
      if (settings.enabled) {
        statusBanner.classList.remove("disabled");
        statusLabel.textContent = "Active \u2022 Amharic Mode";
      } else {
        statusBanner.classList.add("disabled");
        statusLabel.textContent = "Disabled \u2022 Latin Passthrough";
      }
      optNumbers.checked = settings.convertNumbers;
      optPunctuation.checked = settings.convertPunctuation;
      optCorrector.checked = settings.smartCorrection;
      transliterator = new Transliterator({
        convertPunctuation: settings.convertPunctuation,
        convertNumbers: settings.convertNumbers,
        smartCorrection: settings.smartCorrection,
        dictionary: settings.dictionary
      });
      renderQuickTransliteration();
    }
    function renderQuickTransliteration() {
      const raw = quickInput.value;
      if (!raw.trim()) {
        quickOutput.textContent = "\u1230\u120B\u121D \u12ED\u1201\u1295";
        return;
      }
      const res = transliterator.transliterate(raw);
      quickOutput.textContent = res;
    }
    updateUi(currentSettings);
    toggleEnabled.addEventListener("change", async () => {
      const updated = await BrowserStorageAdapter.saveSettings({ enabled: toggleEnabled.checked });
      chrome.runtime.sendMessage({ type: "SET_ENABLED", enabled: updated.enabled });
      updateUi(updated);
    });
    quickInput.addEventListener("input", renderQuickTransliteration);
    btnCopy.addEventListener("click", async () => {
      const text = quickOutput.textContent || "";
      if (text) {
        await navigator.clipboard.writeText(text);
        btnCopy.classList.add("copied");
        setTimeout(() => {
          btnCopy.classList.remove("copied");
        }, 1500);
      }
    });
    optNumbers.addEventListener("change", async () => {
      const updated = await BrowserStorageAdapter.saveSettings({ convertNumbers: optNumbers.checked });
      updateUi(updated);
    });
    optPunctuation.addEventListener("change", async () => {
      const updated = await BrowserStorageAdapter.saveSettings({ convertPunctuation: optPunctuation.checked });
      updateUi(updated);
    });
    optCorrector.addEventListener("change", async () => {
      const updated = await BrowserStorageAdapter.saveSettings({ smartCorrection: optCorrector.checked });
      updateUi(updated);
    });
  });
})();
//# sourceMappingURL=popup.js.map
