"use strict";
(() => {
  // src/browser/storage/types.ts
  var DEFAULT_SETTINGS = {
    enabled: true,
    convertPunctuation: true,
    convertNumbers: true,
    smartCorrection: true,
    suggestions: true,
    defaultSyllableMerging: "merge",
    compositionBoundaryChar: "-",
    compositionMergeChar: "+",
    dictionary: {},
    disabledDomains: []
  };

  // src/browser/storage/storageAdapter.ts
  var BrowserStorageAdapter = class {
    static STORAGE_KEY = "fidel_browser_settings";
    static async getSettings() {
      if (typeof chrome === "undefined" || !chrome.storage) {
        return DEFAULT_SETTINGS;
      }
      return new Promise((resolve) => {
        chrome.storage.sync.get([this.STORAGE_KEY], (result) => {
          if (chrome.runtime.lastError || !result[this.STORAGE_KEY]) {
            chrome.storage.local.get([this.STORAGE_KEY], (localResult) => {
              const localData = localResult?.[this.STORAGE_KEY] || {};
              resolve({ ...DEFAULT_SETTINGS, ...localData });
            });
          } else {
            const syncData = result?.[this.STORAGE_KEY] || {};
            resolve({ ...DEFAULT_SETTINGS, ...syncData });
          }
        });
      });
    }
    static async saveSettings(settings) {
      const current = await this.getSettings();
      const updated = { ...current, ...settings };
      if (typeof chrome !== "undefined" && chrome.storage) {
        await new Promise((resolve) => {
          chrome.storage.sync.set({ [this.STORAGE_KEY]: updated }, () => {
            if (chrome.runtime.lastError) {
              chrome.storage.local.set({ [this.STORAGE_KEY]: updated }, () => resolve());
            } else {
              chrome.storage.local.set({ [this.STORAGE_KEY]: updated }, () => resolve());
            }
          });
        });
      }
      return updated;
    }
    static onSettingsChange(callback) {
      if (typeof chrome === "undefined" || !chrome.storage) return;
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if ((areaName === "sync" || areaName === "local") && changes[this.STORAGE_KEY]) {
          const newValue = changes[this.STORAGE_KEY].newValue;
          if (newValue) {
            callback({ ...DEFAULT_SETTINGS, ...newValue });
          }
        }
      });
    }
  };

  // src/browser/options/options.ts
  document.addEventListener("DOMContentLoaded", async () => {
    const syllableMerging = document.getElementById("syllable-merging");
    const boundaryChar = document.getElementById("boundary-char");
    const mergeChar = document.getElementById("merge-char");
    const checkNumbers = document.getElementById("check-numbers");
    const checkPunctuation = document.getElementById("check-punctuation");
    const checkCorrector = document.getElementById("check-corrector");
    const formAddDict = document.getElementById("form-add-dict");
    const dictKey = document.getElementById("dict-key");
    const dictVal = document.getElementById("dict-val");
    const dictTableBody = document.getElementById("dict-table-body");
    const disabledDomains = document.getElementById("disabled-domains");
    const btnSave = document.getElementById("btn-save");
    const saveStatus = document.getElementById("save-status");
    let currentSettings = await BrowserStorageAdapter.getSettings();
    function renderDictionaryTable() {
      dictTableBody.innerHTML = "";
      const entries = Object.entries(currentSettings.dictionary || {});
      if (entries.length === 0) {
        dictTableBody.innerHTML = '<tr><td colspan="3" class="empty-state">No custom entries yet.</td></tr>';
        return;
      }
      entries.forEach(([key, val]) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
        <td><code>${escapeHtml(key)}</code></td>
        <td><strong>${escapeHtml(val)}</strong></td>
        <td><button class="btn-danger-sm" data-key="${escapeHtml(key)}">Delete</button></td>
      `;
        dictTableBody.appendChild(tr);
      });
      dictTableBody.querySelectorAll(".btn-danger-sm").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          const key = e.currentTarget.getAttribute("data-key");
          if (key && currentSettings.dictionary[key]) {
            delete currentSettings.dictionary[key];
            await BrowserStorageAdapter.saveSettings({ dictionary: currentSettings.dictionary });
            renderDictionaryTable();
            showStatus("Dictionary updated!");
          }
        });
      });
    }
    function escapeHtml(str) {
      return str.replace(/[&<>"']/g, (m) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      })[m] || m);
    }
    function showStatus(msg) {
      saveStatus.textContent = msg;
      setTimeout(() => {
        if (saveStatus.textContent === msg) saveStatus.textContent = "";
      }, 2500);
    }
    syllableMerging.value = currentSettings.defaultSyllableMerging || "merge";
    boundaryChar.value = currentSettings.compositionBoundaryChar || "-";
    mergeChar.value = currentSettings.compositionMergeChar || "+";
    checkNumbers.checked = currentSettings.convertNumbers;
    checkPunctuation.checked = currentSettings.convertPunctuation;
    checkCorrector.checked = currentSettings.smartCorrection;
    disabledDomains.value = (currentSettings.disabledDomains || []).join("\n");
    renderDictionaryTable();
    formAddDict.addEventListener("submit", async (e) => {
      e.preventDefault();
      const key = dictKey.value.trim().toLowerCase();
      const val = dictVal.value.trim();
      if (key && val) {
        currentSettings.dictionary = {
          ...currentSettings.dictionary || {},
          [key]: val
        };
        await BrowserStorageAdapter.saveSettings({ dictionary: currentSettings.dictionary });
        dictKey.value = "";
        dictVal.value = "";
        renderDictionaryTable();
        showStatus("Added to dictionary!");
      }
    });
    btnSave.addEventListener("click", async () => {
      const domains = disabledDomains.value.split("\n").map((s) => s.trim().toLowerCase()).filter((s) => s.length > 0);
      const updated = await BrowserStorageAdapter.saveSettings({
        defaultSyllableMerging: syllableMerging.value,
        compositionBoundaryChar: boundaryChar.value || "-",
        compositionMergeChar: mergeChar.value || "+",
        convertNumbers: checkNumbers.checked,
        convertPunctuation: checkPunctuation.checked,
        smartCorrection: checkCorrector.checked,
        disabledDomains: domains
      });
      currentSettings = updated;
      showStatus("All settings saved successfully! \u2705");
    });
  });
})();
//# sourceMappingURL=options.js.map
